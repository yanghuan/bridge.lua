﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CulturesSerialization
{
    class Program
    {
        static void Main(string[] args)
        {
            var cultures = System.Globalization.CultureInfo.GetCultures(System.Globalization.CultureTypes.AllCultures);
            foreach (var c in cultures)
            {
                var nfi = c.NumberFormat;
                var dfi = c.DateTimeFormat;
                var tIndex = dfi.SortableDateTimePattern.IndexOf("'T'");
                if(tIndex == -1)
                {
                    tIndex = dfi.SortableDateTimePattern.Length;
                }

                var tab1 = "    ";
                var tab2 = tab1 + tab1;

                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Bridge.merge(new Bridge.CultureInfo(\"{0}\", true), {{", c.Name);
                sb.AppendLine();
                sb.Append(tab1).AppendLine("englishName: " + JsonConvert.SerializeObject(c.EnglishName) + ",");
                sb.Append(tab1).AppendLine("nativeName: " + JsonConvert.SerializeObject(c.NativeName) + ",");
                sb.AppendLine();

                sb.Append(tab1).AppendLine("numberFormat: Bridge.merge(new Bridge.NumberFormatInfo(), {");
                sb.Append(tab2).AppendLine("naNSymbol: " + JsonConvert.SerializeObject(nfi.NaNSymbol) + ",");
                sb.Append(tab2).AppendLine("negativeSign: " + JsonConvert.SerializeObject(nfi.NegativeSign) + ",");
                sb.Append(tab2).AppendLine("positiveSign: " + JsonConvert.SerializeObject(nfi.PositiveSign) + ",");
                sb.Append(tab2).AppendLine("negativeInfinitySymbol: " + JsonConvert.SerializeObject(nfi.NegativeInfinitySymbol) + ",");
                sb.Append(tab2).AppendLine("positiveInfinitySymbol: " + JsonConvert.SerializeObject(nfi.PositiveInfinitySymbol) + ",");
                sb.Append(tab2).AppendLine("percentSymbol: " + JsonConvert.SerializeObject(nfi.PercentSymbol) + ",");
                sb.Append(tab2).AppendLine("percentGroupSizes: " + JsonConvert.SerializeObject(nfi.PercentGroupSizes) + ",");
                sb.Append(tab2).AppendLine("percentDecimalDigits: " + JsonConvert.SerializeObject(nfi.PercentDecimalDigits) + ",");
                sb.Append(tab2).AppendLine("percentDecimalSeparator: " + JsonConvert.SerializeObject(nfi.PercentDecimalSeparator) + ",");
                sb.Append(tab2).AppendLine("percentGroupSeparator: " + JsonConvert.SerializeObject(nfi.PercentGroupSeparator) + ",");
                sb.Append(tab2).AppendLine("percentPositivePattern: " + JsonConvert.SerializeObject(nfi.PercentPositivePattern) + ",");
                sb.Append(tab2).AppendLine("percentNegativePattern: " + JsonConvert.SerializeObject(nfi.PercentNegativePattern) + ",");
                sb.Append(tab2).AppendLine("currencySymbol: " + JsonConvert.SerializeObject(nfi.CurrencySymbol) + ",");
                sb.Append(tab2).AppendLine("currencyGroupSizes: " + JsonConvert.SerializeObject(nfi.CurrencyGroupSizes) + ",");
                sb.Append(tab2).AppendLine("currencyDecimalDigits: " + JsonConvert.SerializeObject(nfi.CurrencyDecimalDigits) + ",");
                sb.Append(tab2).AppendLine("currencyDecimalSeparator: " + JsonConvert.SerializeObject(nfi.CurrencyDecimalSeparator) + ",");
                sb.Append(tab2).AppendLine("currencyGroupSeparator: " + JsonConvert.SerializeObject(nfi.CurrencyGroupSeparator) + ",");
                sb.Append(tab2).AppendLine("currencyNegativePattern: " + JsonConvert.SerializeObject(nfi.CurrencyNegativePattern) + ",");
                sb.Append(tab2).AppendLine("currencyPositivePattern: " + JsonConvert.SerializeObject(nfi.CurrencyPositivePattern) + ",");
                sb.Append(tab2).AppendLine("numberGroupSizes: " + JsonConvert.SerializeObject(nfi.NumberGroupSizes) + ",");
                sb.Append(tab2).AppendLine("numberDecimalDigits: " + JsonConvert.SerializeObject(nfi.NumberDecimalDigits) + ",");
                sb.Append(tab2).AppendLine("numberDecimalSeparator: " + JsonConvert.SerializeObject(nfi.NumberDecimalSeparator) + ",");
                sb.Append(tab2).AppendLine("numberGroupSeparator: " + JsonConvert.SerializeObject(nfi.NumberGroupSeparator) + ",");
                sb.Append(tab2).AppendLine("numberNegativePattern: " + JsonConvert.SerializeObject(nfi.NumberNegativePattern));
                sb.Append(tab1).AppendLine("}),");
                sb.AppendLine();

                sb.Append(tab1).AppendLine("dateTimeFormat: Bridge.merge(new Bridge.DateTimeFormatInfo(), {");

                sb.Append(tab2).AppendLine("abbreviatedDayNames: " + JsonConvert.SerializeObject(dfi.AbbreviatedDayNames) + ",");
                sb.Append(tab2).AppendLine("abbreviatedMonthGenitiveNames: " + JsonConvert.SerializeObject(dfi.AbbreviatedMonthGenitiveNames) + ",");
                sb.Append(tab2).AppendLine("abbreviatedMonthNames: " + JsonConvert.SerializeObject(dfi.AbbreviatedMonthNames) + ",");
                sb.Append(tab2).AppendLine("amDesignator: " + JsonConvert.SerializeObject(dfi.AMDesignator) + ",");
                sb.Append(tab2).AppendLine("dateSeparator: " + JsonConvert.SerializeObject(dfi.DateSeparator) + ",");
                sb.Append(tab2).AppendLine("dayNames: " + JsonConvert.SerializeObject(dfi.DayNames) + ",");
                sb.Append(tab2).AppendLine("firstDayOfWeek: " + JsonConvert.SerializeObject(dfi.FirstDayOfWeek) + ",");
                sb.Append(tab2).AppendLine("fullDateTimePattern: " + JsonConvert.SerializeObject(dfi.FullDateTimePattern) + ",");
                sb.Append(tab2).AppendLine("longDatePattern: " + JsonConvert.SerializeObject(dfi.LongDatePattern) + ",");
                sb.Append(tab2).AppendLine("longTimePattern: " + JsonConvert.SerializeObject(dfi.LongTimePattern) + ",");
                sb.Append(tab2).AppendLine("monthDayPattern: " + JsonConvert.SerializeObject(dfi.MonthDayPattern) + ",");
                sb.Append(tab2).AppendLine("monthGenitiveNames: " + JsonConvert.SerializeObject(dfi.MonthGenitiveNames) + ",");
                sb.Append(tab2).AppendLine("monthNames: " + JsonConvert.SerializeObject(dfi.MonthNames) + ",");
                sb.Append(tab2).AppendLine("pmDesignator: " + JsonConvert.SerializeObject(dfi.PMDesignator) + ",");
                sb.Append(tab2).AppendLine("rfc1123: " + JsonConvert.SerializeObject(dfi.RFC1123Pattern) + ",");
                sb.Append(tab2).AppendLine("shortDatePattern: " + JsonConvert.SerializeObject(dfi.ShortDatePattern) + ",");
                sb.Append(tab2).AppendLine("shortestDayNames: " + JsonConvert.SerializeObject(dfi.ShortestDayNames) + ",");
                sb.Append(tab2).AppendLine("shortTimePattern: " + JsonConvert.SerializeObject(dfi.ShortTimePattern) + ",");
                sb.Append(tab2).AppendLine("sortableDateTimePattern: " + JsonConvert.SerializeObject(dfi.SortableDateTimePattern) + ",");
                sb.Append(tab2).AppendLine("sortableDateTimePattern1: " + JsonConvert.SerializeObject(dfi.SortableDateTimePattern.Substring(0, tIndex)) + ",");
                sb.Append(tab2).AppendLine("timeSeparator: " + JsonConvert.SerializeObject(dfi.TimeSeparator) + ",");
                sb.Append(tab2).AppendLine("universalSortableDateTimePattern: " + JsonConvert.SerializeObject(dfi.UniversalSortableDateTimePattern) + ",");
                sb.Append(tab2).AppendLine("yearMonthPattern: " + JsonConvert.SerializeObject(dfi.YearMonthPattern) + ",");
                sb.Append(tab2).AppendLine("roundtripFormat: " + JsonConvert.SerializeObject(dfi.SortableDateTimePattern + ".uzzz"));

                sb.Append(tab1).AppendLine("})");
                sb.AppendLine("});");

                File.WriteAllText(c.Name + ".js", sb.ToString(), System.Text.UTF8Encoding.UTF8);
            }
        }
    }
}
