local System = System
local throw = System.throw
local Double = System.Double
local InvalidCastException = System.InvalidCastException

local type = type
local getmetatable = getmetatable
local tinsert = table.insert
local ipairs = ipairs

local Type = {}
local numberType = setmetatable({ c = Double, name = "Number", fullName = "System.Number" }, Type)
local types = {
    [System.Char] = numberType,
    [System.Int] = numberType,
    [Double] = numberType,
}

local function typeof(cls)
    assert(cls)
    local type = types[cls]
    if type == nil then
        type = setmetatable({ c = cls }, Type)
        types[cls] = type
    end
    return type
end

local function getType(obj)
    return typeof(getmetatable(obj))
end

System.Object.GetType = getType
System.typeof = typeof

local function isGenericName(name)
    return name:byte(#name) == 93
end

function Type.getIsGenericType(this)
    return isGenericName(this.c.__name__)
end

function Type.getIsEnum(this)
    return this.c.__kind__ == "E"
end

function Type.getName(this)
    local name = this.name
    if name == nil then
        local clsName = this.c.__name__
        local pattern = isGenericName(clsName) and "^.*()%.(.*)%[.+%]$" or "^.*()%.(.*)$"
        name = clsName:gsub(pattern, "%2")
        this.name = name
    end
    return name
end

function Type.getFullName(this)
    local fullName = this.fullName
    if fullName == nil then
        fullName = this.c.__name__
        this.fullName = fullName
    end
    return fullName
end

function Type.getNamespace(this)
    local namespace = this.namespace
    if namespace == nil then
        local clsName = this.c.__name__
        local pattern = isGenericName(clsName) and "^(.*)()%..*%[.+%]$" or "^(.*)()%..*$"
        namespace = clsName:gsub(pattern, "%1")
        this.namespace = namespace
    end
    return namespace
end

local function getBaseType(this)
    local baseType = this.baseType
    if baseType == nil then
        local baseCls = this.c.__base__
        if baseCls ~= nil then
            baseType = typeof(baseCls)
            this.baseType = baseType
        end
    end 
    return baseType
end

Type.getBaseType = getBaseType

local function isSubclassOf(this, c)
    local p = this
    if p == c then
        return false
    end
    while p ~= nil do
        if p == c then
            return true
        end
        p = getBaseType(p)
    end
end

Type.IsSubclassOf = isSubclassOf

local function getIsInterface(this)
    return this.c.__kind__ == "I"
end

Type.getIsInterface = getIsInterface

local function getIsValueType(this)
    return this.c.__kind__ == "S"
end

Type.getIsValueType = getIsValueType

local function getInterfaces(this)
    local interfaces = this.interfaces
    if interfaces == nil then
        interfaces = {}
        local interfacesCls = this.c.__interfaces__
        if interfacesCls ~= nil then
            for _, i in ipairs(interfacesCls) do
                tinsert(interfaces, typeof(i))
            end
        end
        this.interfaces = System.arrayFromTable(interfaces, Type)
    end
    return interfaces
end

Type.getInterfaces = getInterfaces

local function implementInterface(this, ifaceType)
    local t = this
    while t ~= nil do
        local interfaces = getInterfaces(this)
        if interfaces ~= nil then
            for _, i in ipairs(interfaces) do
                if i == ifaceType or implementInterface(i, ifaceType) then
                    return true
                end
            end
        end
        t = getBaseType(t)
    end
    return false
end

local function isAssignableFrom(this, c)
    if c == nil then 
        return false 
    end
    if this == c then 
        return true 
    end
    if isSubclassOf(c, this) then
        return true
    end
    if getIsInterface(this) then
        return implementInterface(c, this)
    end
    return false
end 

Type.IsAssignableFrom = isAssignableFrom

function Type.IsInstanceOfType(this, obj)
    if obj == nil then
        return false 
    end
    return isAssignableFrom(this, obj:GetType())
end

function Type.ToString(this)
    return this.c.__name__
end

System.define("System.Type", Type)

function is(obj, cls)
    if obj ~= nil then 
        return isAssignableFrom(typeof(cls), obj:GetType())
    end
    return false
end

System.is = is

function System.as(obj, cls)
    if is(obj, cls) then
        return obj
    end
    return nil
end

function System.cast(obj, cls)
    if is(obj, cls) then
        return obj
    end
    if obj == nil and cls.__kind__ ~= "S" then
        return nil
    end
    throw(InvalidCastException(), 1)
end